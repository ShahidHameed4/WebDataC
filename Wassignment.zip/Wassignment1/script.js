function addtable(){
    var table =document.getElementById("table");
    var row = document.createElement("tr");
    // var cell1 = row.insertCell(0);
    // var cell2 = row.insertCell(1);
    // cell1.innerHTML = "New Cell1";
    // cell2.innerHTML = "New Cell2";
    table.appendChild(row);
    

}

addtable();